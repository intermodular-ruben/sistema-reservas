/* =========================================================
   UD5-UT5 (Oracle) + UT7 Consultas
  
   - Oracle NO tiene ON UPDATE en FK (se gestiona con l�gica / triggers si hiciera falta)
   - ON DELETE:
     * Subtipos (ADMIN/USUARIONORMAL) -> CASCADE (si se borra USUARIO, se borra el subtipo)
     * DISPONIBLEEN -> CASCADE (si se borra RECURSO u HORARIO, se borra disponibilidad)
     * RESERVA -> CASCADE con RECURSO y USUARIONORMAL (si se borra recurso o usuario normal, se borran reservas)
   ========================================================= */

-- =======================
-- DROP (orden inverso)
-- =======================
BEGIN EXECUTE IMMEDIATE 'DROP TABLE RESERVA CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE DISPONIBLEEN CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE HORARIO CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE RECURSO CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE USUARIONORMAL CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE ADMINISTRADOR CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE USUARIO CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/

-- =======================
-- CREATE TABLES
-- =======================

CREATE TABLE USUARIO(
  id_usuario        NUMBER(3) CONSTRAINT pk_usuario PRIMARY KEY,
  correo_electronico VARCHAR2(100) CONSTRAINT uq_usuario_correo UNIQUE NOT NULL,
  contrasena        VARCHAR2(100) NOT NULL,
  nombre            VARCHAR2(100) NOT NULL,
  fecha_nacimiento  DATE,
  tipo_usuario      VARCHAR2(20) NOT NULL,
  CONSTRAINT ck_usuario_tipo CHECK (tipo_usuario IN ('Administrador','Normal'))
);

-- Subtipo ADMINISTRADOR
CREATE TABLE ADMINISTRADOR(
  id_usuario       NUMBER(3) CONSTRAINT pk_admin PRIMARY KEY,
  telefono_guardia VARCHAR2(20) NOT NULL,
  CONSTRAINT fk_admin_usuario
    FOREIGN KEY (id_usuario) REFERENCES USUARIO(id_usuario)
    ON DELETE CASCADE
  -- ON UPDATE: Oracle no lo soporta
);

-- Subtipo USUARIONORMAL
CREATE TABLE USUARIONORMAL(
  id_usuario     NUMBER(3) CONSTRAINT pk_unormal PRIMARY KEY,
  direccion      VARCHAR2(200),
  telefono_movil VARCHAR2(20),
  fotografia     VARCHAR2(255),
  CONSTRAINT fk_unormal_usuario
    FOREIGN KEY (id_usuario) REFERENCES USUARIO(id_usuario)
    ON DELETE CASCADE
  -- ON UPDATE: Oracle no lo soporta
);

CREATE TABLE RECURSO(
  id_recurso  NUMBER(3) CONSTRAINT pk_recurso PRIMARY KEY,
  nombre      VARCHAR2(100) NOT NULL,
  descripcion VARCHAR2(100),
  ubicacion   VARCHAR2(200),
  capacidad   NUMBER(3),
  CONSTRAINT ck_recurso_cap CHECK (capacidad IS NULL OR capacidad >= 0)
);

CREATE TABLE HORARIO(
  id_horario  NUMBER(3) CONSTRAINT pk_horario PRIMARY KEY,
  dia_semana  VARCHAR2(10) NOT NULL,
  hora_inicio CHAR(5) NOT NULL,
  hora_fin    CHAR(5) NOT NULL,
  CONSTRAINT ck_horario_dia CHECK (dia_semana IN ('Lunes','Martes','Mi�rcoles','Jueves','Viernes','S�bado','Domingo')),
  CONSTRAINT ck_horario_horas CHECK (hora_fin > hora_inicio)
);

CREATE TABLE DISPONIBLEEN(
  id_recurso NUMBER(3) NOT NULL,
  id_horario NUMBER(3) NOT NULL,
  CONSTRAINT pk_disponible PRIMARY KEY (id_recurso, id_horario),
  CONSTRAINT fk_disp_recurso FOREIGN KEY (id_recurso) REFERENCES RECURSO(id_recurso) ON DELETE CASCADE,
  CONSTRAINT fk_disp_horario FOREIGN KEY (id_horario) REFERENCES HORARIO(id_horario) ON DELETE CASCADE
  -- ON UPDATE: Oracle no lo soporta
);

CREATE TABLE RESERVA(
  id_recurso       NUMBER(3) NOT NULL,
  id_reserva_local NUMBER(3) NOT NULL,
  id_usuario       NUMBER(3) NOT NULL,
  fecha            DATE NOT NULL,
  hora_inicio      CHAR(5) NOT NULL,
  hora_fin         CHAR(5) NOT NULL,
  coste            NUMBER(10,2),
  numero_plazas    NUMBER(3),
  motivo           VARCHAR2(20),
  observaciones    VARCHAR2(20),
  CONSTRAINT pk_reserva PRIMARY KEY (id_recurso, id_reserva_local),
  CONSTRAINT fk_res_recurso FOREIGN KEY (id_recurso) REFERENCES RECURSO(id_recurso) ON DELETE CASCADE,
  CONSTRAINT fk_res_unormal FOREIGN KEY (id_usuario) REFERENCES USUARIONORMAL(id_usuario) ON DELETE CASCADE,
  CONSTRAINT ck_res_horas CHECK (hora_fin > hora_inicio),
  CONSTRAINT ck_res_plazas CHECK (numero_plazas IS NULL OR numero_plazas > 0),
  CONSTRAINT ck_res_coste CHECK (coste IS NULL OR coste >= 0)
  -- ON UPDATE: Oracle no lo soporta
);

-- =======================
-- INSERTS (5 filas por tabla)
-- =======================

-- USUARIO (m�nimo 5; aqu� meto 10 para tener 5 admin + 5 normal sin complicaciones)
INSERT INTO USUARIO VALUES (1,'admin1@uni.com','pass','Ruben',DATE '1980-01-01','Administrador');
INSERT INTO USUARIO VALUES (2,'admin2@uni.com','pass','Ana Admin',DATE '1985-02-02','Administrador');
INSERT INTO USUARIO VALUES (3,'admin3@uni.com','pass','Luis Admin',DATE '1982-03-03','Administrador');
INSERT INTO USUARIO VALUES (4,'admin4@uni.com','pass','Marta Admin',DATE '1990-04-04','Administrador');
INSERT INTO USUARIO VALUES (5,'admin5@uni.com','pass','Javi Admin',DATE '1992-05-05','Administrador');

INSERT INTO USUARIO VALUES (6,'user1@uni.com','pass','Carlos Normal',DATE '1995-06-06','Normal');
INSERT INTO USUARIO VALUES (7,'user2@uni.com','pass','Lucia Normal',DATE '1996-07-07','Normal');
INSERT INTO USUARIO VALUES (8,'user3@uni.com','pass','Pepe Normal',DATE '1997-08-08','Normal');
INSERT INTO USUARIO VALUES (9,'user4@uni.com','pass','Sonia Normal',DATE '1998-09-09','Normal');
INSERT INTO USUARIO VALUES (10,'user5@uni.com','pass','Nuria Normal',DATE '1999-10-10','Normal');

-- ADMINISTRADOR (5) -> tu nombre dentro ?
INSERT INTO ADMINISTRADOR VALUES (1,'600111111'); -- Ruben (autor�a)
INSERT INTO ADMINISTRADOR VALUES (2,'600222222');
INSERT INTO ADMINISTRADOR VALUES (3,'600333333');
INSERT INTO ADMINISTRADOR VALUES (4,'600444444');
INSERT INTO ADMINISTRADOR VALUES (5,'600555555');

-- USUARIONORMAL (5)
INSERT INTO USUARIONORMAL VALUES (6,'C/ A 1','700111111','foto1.jpg');
INSERT INTO USUARIONORMAL VALUES (7,'C/ B 2','700222222','foto2.jpg');
INSERT INTO USUARIONORMAL VALUES (8,'C/ C 3','700333333','foto3.jpg');
INSERT INTO USUARIONORMAL VALUES (9,'C/ D 4','700444444','foto4.jpg');
INSERT INTO USUARIONORMAL VALUES (10,'C/ E 5','700555555','foto5.jpg');

-- RECURSO (5)
INSERT INTO RECURSO VALUES (1,'Sala Reuniones A','Sala con proyector','Planta 1',20);
INSERT INTO RECURSO VALUES (2,'Pista Tenis','Pista exterior','Zona deportiva',4);
INSERT INTO RECURSO VALUES (3,'Aula Informatica','PCs y red','Edificio B',25);
INSERT INTO RECURSO VALUES (4,'Gimnasio','Pesas y cardio','Planta baja',30);
INSERT INTO RECURSO VALUES (5,'Sala Eventos','Actos y charlas','Planta 2',100);

-- HORARIO (5)
INSERT INTO HORARIO VALUES (1,'Lunes','09:00','11:00');
INSERT INTO HORARIO VALUES (2,'Martes','16:00','18:00');
INSERT INTO HORARIO VALUES (3,'Mi�rcoles','10:00','12:00');
INSERT INTO HORARIO VALUES (4,'Jueves','18:00','20:00');
INSERT INTO HORARIO VALUES (5,'Viernes','08:00','10:00');

-- DISPONIBLEEN (5)
INSERT INTO DISPONIBLEEN VALUES (1,1);
INSERT INTO DISPONIBLEEN VALUES (1,3);
INSERT INTO DISPONIBLEEN VALUES (2,2);
INSERT INTO DISPONIBLEEN VALUES (3,5);
INSERT INTO DISPONIBLEEN VALUES (5,4);

-- RESERVA (5) (mismo usuario puede reservar varias -> usuario 6 repite ?)
INSERT INTO RESERVA VALUES (1,1,6,DATE '2025-02-01','09:00','10:00',10.00,2,'Reunion','OK');
INSERT INTO RESERVA VALUES (1,2,6,DATE '2025-02-02','10:00','11:00',10.00,2,'Reunion','OK');
INSERT INTO RESERVA VALUES (2,1,7,DATE '2025-03-10','16:00','18:00',5.00,2,'Deporte','-');
INSERT INTO RESERVA VALUES (3,1,8,DATE '2025-01-15','08:00','10:00',0.00,1,'Estudio','-');
INSERT INTO RESERVA VALUES (5,1,9,DATE '2025-04-05','18:00','20:00',20.00,10,'Evento','-');

COMMIT;

-- =======================
-- UT7 - CONSULTAS (capturas PDF)
-- =======================

-- 1) Datos de los administradores: correo, nombre, tel�fono
SELECT u.correo_electronico AS correo, u.nombre, a.telefono_guardia AS telefono
FROM USUARIO u
JOIN ADMINISTRADOR a ON a.id_usuario = u.id_usuario
ORDER BY u.id_usuario;

-- 2) Para cada reserva, los datos del usuario que la ha realizado
SELECT r.id_recurso, r.id_reserva_local, r.fecha, r.hora_inicio, r.hora_fin,
       u.id_usuario, u.correo_electronico AS correo, u.nombre
FROM RESERVA r
JOIN USUARIONORMAL un ON un.id_usuario = r.id_usuario
JOIN USUARIO u ON u.id_usuario = un.id_usuario
ORDER BY r.id_recurso, r.id_reserva_local;

-- 3) Para cada recurso, la informaci�n de los horarios que hay disponible
SELECT re.id_recurso, re.nombre AS recurso, re.ubicacion,
       h.dia_semana, h.hora_inicio, h.hora_fin
FROM RECURSO re
JOIN DISPONIBLEEN d ON d.id_recurso = re.id_recurso
JOIN HORARIO h ON h.id_horario = d.id_horario
ORDER BY re.id_recurso, h.id_horario;

-- RA4 extra (DML): UPDATE y DELETE de ejemplo (y revertimos para no cambiar el dataset final)

UPDATE RECURSO
SET capacidad = capacidad + 1
WHERE id_recurso = 1;

UPDATE RECURSO
SET capacidad = capacidad - 1
WHERE id_recurso = 1;

DELETE FROM RESERVA
WHERE id_recurso = 3 AND id_reserva_local = 1;

INSERT INTO RESERVA VALUES (3,1,8,DATE '2025-01-15','08:00','10:00',0.00,1,'Estudio','-');

COMMIT;



